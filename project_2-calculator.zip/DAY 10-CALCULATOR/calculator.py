def calculator1():
    first_num=int(input("Enter the first number :"))
    print("+\n-\n*\n/")
    operation = input("Pick your operation:")
    second_num=int(input("enter the second number:"))
    calculation_continue=True

    def calculator(a,b,operation):
        if operation=="+":
            result=a+b
        elif operation=="-":
           result=a-b
        elif operation=="*":
            result=a*b
        else:
            result=a/b
        print(result)
        continue_calc=input("enter y to continue with output or n for new calculation:")
        if continue_calc=="y":
            calculation_continue=True
        else:
           calculation_continue=False
           print("\n"*100)
           calculator1()
        return result


    output=calculator(first_num,second_num,operation)

    while calculation_continue:
        print("+\n-\n*\n/")
        operation = input("Pick your operation:")
        second_num=int(input("enter the second number:"))
        output = calculator(output,second_num, operation)

calculator1()