import random

letters=['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
symbols=['!','@','$','#']
number=['1','2','3','4','5','6','7','8','9','0']

n_letters=int(input("enter the no of letters:"))
n_symbols=int(input("enter the no of symbols:"))
n_numbers=int(input("enter the no of numbers:"))

password_list=[]
for char in range(0,n_letters):
    password_list+=random.choice(letters)
for n in range(0,n_numbers):
    password_list+=random.choice(number)
for sym in range (0,n_symbols):
    password_list+=random.choice(symbols)


random.shuffle(password_list)


password=""
for charac in password_list:
    password+=charac
print(f"Your password is {password}")
