from question_model import Question
from data import question_data
from quiz_brain import QuizBrain

questions = question_data
question_bank = []
for i in  questions :
    question_text=i["text"]
    question_ans=i["answer"]
    question_add=Question(text=question_text,answer=question_ans)
    question_bank.append(question_add)

# print(question_bank)
quiz = QuizBrain(question_bank)
quiz.next_question()