from tkinter import *
from pandas import *
import random

BACKGROUND_COLOR = "#B1DDC6"
to_listen = {}
current_card = {}
flip_timer = None

try:
    data = read_csv("data/word_to_listen.csv")
except FileNotFoundError:
    original_data = read_csv("data/french_words.csv")
    to_listen = original_data.to_dict(orient="records")
else:
    to_listen = data.to_dict(orient="records")

def word_change():
    global current_card, flip_timer
    if flip_timer:
        window.after_cancel(flip_timer)
    current_card = random.choice(to_listen)
    canvas.itemconfig(image_bg, image=photo)
    canvas.itemconfig(card_title, text="French", fill="black")
    canvas.itemconfig(card_word, text=current_card["French"], fill="black")
    flip_timer = window.after(3000, func=flip_card)

def flip_card():
    canvas.itemconfig(card_title, text="English", fill="white")
    canvas.itemconfig(card_word, text=current_card["English"], fill="white")
    canvas.itemconfig(image_bg, image=photo1)


def is_known():
    to_listen.remove(current_card)
    data = DataFrame(to_listen)
    data.to_csv("data/word_to_listen.csv", index=False)
    word_change()

window = Tk()
window.title("Flashy")
window.config(padx=50, pady=50, bg=BACKGROUND_COLOR)

flip_timer = window.after(3000, func=flip_card)

# UI Setup
canvas = Canvas(width=800, height=526, highlightthickness=0)
photo = PhotoImage(file="images/card_front.png")
photo1 = PhotoImage(file="images/card_back.png")
image_bg = canvas.create_image(400, 263, image=photo)
canvas.config(bg=BACKGROUND_COLOR)
card_title = canvas.create_text(400, 150, text="Title", font=("Ariel", 40, "italic"))
card_word = canvas.create_text(400, 263, text="word", font=("Ariel", 60, "bold"))
canvas.grid(row=0, column=0, columnspan=2)

# Buttons
correct_pic = PhotoImage(file="images/right.png")
right_button = Button(image=correct_pic, highlightthickness=0, command=is_known)
right_button.grid(row=1, column=1)

wrong_pic = PhotoImage(file="images/wrong.png")
wrong_button = Button(image=wrong_pic, highlightthickness=0, command=word_change)
wrong_button.grid(row=1, column=0)

# Start the program with a new word
word_change()

window.mainloop()
