from menu import MenuItem,Menu
from coffee_maker import CoffeeMaker
from money_machine import MoneyMachine

coffee_machine= CoffeeMaker()
money_machine= MoneyMachine()
menu= Menu()

is_on=True

while is_on:
     choice=menu.get_items()
     order = input(f"What would you like to have {choice}:").lower()
     if order == "off":
          is_on=False
     elif order =="report":
          coffee_machine.report()
          money_machine.report()
     else:
          is_there= menu.find_drink(order)
          is_sufficient=coffee_machine.is_resource_sufficient(is_there)
          if is_sufficient==True:
               money_required= money_machine.make_payment(is_there.cost)
               if money_required==True:
                    make_order = coffee_machine.make_coffee(is_there)
               else:
                    print("Money are not sufficient to make the coffee")
          else:
               print("Can't make that order !!!")

