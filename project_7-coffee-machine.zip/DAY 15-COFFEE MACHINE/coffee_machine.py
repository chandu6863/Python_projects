from random import choice
machine="on"


def coins_collector(choice,trail,resources):
    print("please insert the coins:")
    quarter = int(input("how many quarter's:"))
    dime = int(input("how many dime's:"))
    nickel = int(input("how many nickel's:"))
    penny = int(input("how many penny's:"))
    coins_collected=quarter*0.25+dime*0.10+nickel*0.05+penny*0.01
    if coins_collected>=choice["cost"]:
        change=coins_collected-choice["cost"]
        resources["water"]-=choice["ingredients"]["water"]
        resources["milk"] -= choice["ingredients"]["milk"]
        resources["coffee"] -= choice["ingredients"]["coffee"]
        resources["money"]+=choice["cost"]
        print(f"Here is your change {change}")
        print(f"Here is your {trail} .Enjoy")
    else:
        print(f"Sorry.That's not enough money.Money refunded")


def compare(choice,resources,trail):
    global machine
    if choice["ingredients"]["water"]<=resources["water"]:
        if choice["ingredients"]["coffee"]<=resources["coffee"]:
            if choice["ingredients"]["milk"]<=resources["milk"]:
                coins_collector(choice,trail,resources)
            else:
                print("Sorry there is not enough milk.")
        else:
            print("Sorry there is not enough coffee.")
    else:
        print("Sorry there is not enough water.")



MENU = {
    "espresso": {
        "ingredients": {
            "water": 50,
            "milk":0,
            "coffee": 18,
        },
        "cost": 1.5,
    },
    "latte": {
        "ingredients": {
            "water": 200,
            "milk": 150,
            "coffee": 24,
        },
        "cost": 2.5,
    },
    "cappuccino": {
        "ingredients": {
            "water": 250,
            "milk": 100,
            "coffee": 24,
        },
        "cost": 3.0,
    }
}

resources= {
    "water":300,
    "milk":200,
    "coffee":100,
    "money":0
}


while machine=="on":
    trail=input("what would you like .(expresso,latte or cappuccino):").lower()
    if trail=="report":
        print(resources)
    elif trail=="espresso":
        choice=MENU["espresso"]
        compare(choice,resources,trail)
    elif trail=="latte":
        choice=MENU["latte"]
        compare(choice, resources, trail)
    elif trail=="cappuccino":
        choice=MENU["cappuccino"]
        compare(choice, resources, trail)
    elif trail=="off":
        machine="off"
    else:
        print("we cannot provide that coffee right now")
