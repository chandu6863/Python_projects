game=True
i=0
def highlow(a_dict,b_dict,i):
    guess=input("Guess which has more followers.Either A or B:").upper()
    if guess=="A":
        guess=a_dict
        other=b_dict
    else:
        guess = b_dict
        other = a_dict
    guessing(guess,other,i)

while game:
    import random
    from day_14_data import data
    a_dict= random.choice(data)
    name_a=a_dict["name"]
    descri_a=a_dict["description"]
    country_a=a_dict["country"]
    print(f"Compare A:{name_a},{descri_a},{country_a}")
    b_dict=random.choice(data)
    if b_dict==a_dict:
        b_dict=random.choice(data)
    name_b=b_dict["name"]
    descri_b=b_dict["description"]
    country_b=b_dict["country"]
    print (f"Against B:{name_b},{descri_b},{country_b}")

    guess=input("Guess which has more followers.Either A or B:").upper()
    if guess=="A":
        guess=a_dict
        other=b_dict
    else:
        guess=b_dict
        other=a_dict
    # guessed should have the highest followers
    def guessing(guess,other,i):
        if guess["follower_count"]>=other["follower_count"]:
            i+=1
            print("Your score is ",i)
            a_dict=guess
            name1_a=a_dict["name"]
            # print(name1_a)
            descri1_a=a_dict["description"]
            country1_a=a_dict["country"]
            b_dict1=random.choice(data)
            # print(b_dict1)
            name1_b=b_dict1["name"]
            # print(name1_b)
            descri1_b=b_dict1["description"]
            country1_b=b_dict1["country"]
            print(f"Compare A:{name1_a},{descri1_a},{country1_a}")
            print(f"Against B:{name1_b},{descri1_b},{country1_b}")
            highlow(a_dict,b_dict1,i)
            # if guess!=other:

        else:
            print("Your score is ",i)
            continue_game=input("Do you want to play again:").lower()
            if continue_game=="y":
                return True
            else:
                print("Thanks for playing")
                return False

    game=guessing(guess,other,i)