import random

play=input("Do you want to play the Black jack game.Type y to play or n to no:\n").lower()
if play=="y":
    print("\n"*100)

    cards=[11,2,3,4,5,6,7,8,9,10,10,10,10]
    my_cards=[]
    computer_cards=[]
    current_sum=0
    current_total=0

    def black_jack(current_total):

            another_picked_card = random.choice(cards)
            # same as the user case
            if current_total>10 and another_picked_card==11:
                 another_picked_card=1
            computer_cards.append(another_picked_card)
            current_total+= another_picked_card
            print(f"Computer cards:{computer_cards}")
            print(current_total)
            if current_total>21:
                print("You won the game!!")
            elif current_total > current_sum and current_total<21:
                print("You lose !!Computer won the game")
            elif current_sum==current_total:
                print("The game is tie,Bet was returned")
            else:
                black_jack(current_total)



    for i in range (0,2):
        cards_picked=random.choice(cards)
        my_cards.append(cards_picked)
        current_sum+=my_cards[i]
    picked_cards=random.choice(cards)
    computer_cards.append(picked_cards)
    current_total+=picked_cards
    print(f"Your cards:{my_cards}")
    print(f"Current total:{current_sum}")
    print(f"Computer cards:{computer_cards}")
    if current_sum==21:
        print("You won the game")
    else:
        another_card=input("Type y for another card or n for pass:\n").lower()
        if another_card=="y":
            continue_game=True
            while continue_game:
                another_card_picked=random.choice(cards)
                #when the current_sum is greater than 10 and another card picked should be 1 if the picked card is 11
                if current_sum>10 and another_card_picked==11:
                    another_card_picked=1

                my_cards.append(another_card_picked)
                current_sum+=another_card_picked
                print(my_cards)
                print(current_sum)
                if current_sum==21:
                    print("You won the game!!")
                elif current_sum<21:
                    continue_game=input("Do you continue the game . Type y for continue or n for no").lower()
                    if continue_game=="n":
                        continue_game = False
                        black_jack(current_total)
                    else:
                        continue_game=True
                else:
                    print("You lost the game!!")
                    continue_game=False
                    break

        else:
            black_jack(current_total)
else:
    print("OK,Good Bye!")