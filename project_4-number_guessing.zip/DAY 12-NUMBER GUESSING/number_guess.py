import random

print("Welcome to number guessing game !!")
level=input("which do you want to play .Easy or Hard\n").lower()
random_number=random.randint(1,10)
if level=="easy":
    attempts=10
else:
    attempts=5
i=attempts
while i>=1:
    print(f"You have {i} attempts remaining .Guess a number")
    guess_number=int(input("Make a guess:"))
    if guess_number==random_number:
        print("You guessed a correct number")
        break
    elif guess_number<random_number:
        print("Too low")
        print("Guess again.")
    else:
        print("Too high \n Guess again.")
    i-=1
    if i==0:
        print("Out of attempts!!")
        break