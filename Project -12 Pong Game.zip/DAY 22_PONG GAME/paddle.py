from turtle import Turtle

class Paddle(Turtle):

    def __init__(self,a,b):
        super().__init__()
        self.a=a
        self.b = b
        self.penup()
        self.shape("square")
        self.color("white")
        self.shapesize(stretch_len=1, stretch_wid=5)
        self.goto(x=self.a, y=self.b)

    def go_up(self):
        if self.ycor()<=240:
            new_y = self.ycor()+20
            self.goto(self.xcor(),new_y)

    def go_down(self):
        if self.ycor() >-240:
            new_y = self.ycor()-20
            self.goto(self.xcor(),new_y)
