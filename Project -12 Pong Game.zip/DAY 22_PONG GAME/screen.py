import time

from ball import Ball
from turtle import  Screen
from paddle import Paddle
from scoreboard import Score


screen = Screen()
screen.title("PONG GAME")
screen.setup(800,600)
screen.bgcolor("Black")
screen.tracer(0)

r_paddle = Paddle(a=350 ,b=0)
l_paddle = Paddle(a=-350,b=0)
r_score = Score(a=100,b=200)
l_score = Score(a=-100,b=200)
ball = Ball()


screen.listen()
screen.onkey(r_paddle.go_up,"Up")
screen.onkey(r_paddle.go_down,"Down")
screen.onkey(l_paddle.go_up,"w")
screen.onkey(l_paddle.go_down,"s")

game_on = True
while game_on:
    time.sleep(ball.speeed)
    screen.update()
    ball.mov()

#detect the collision with top and bottom
    if ball.ycor()>280 or ball.ycor()<-280:
        ball.bounce_y()

#detect the collision at the paddles
    if ball.distance(r_paddle)<50 and ball.xcor()>320 or ball.distance(l_paddle)<50 and ball.xcor()>-340 :
        ball.bounce_x()

#detect the miss at the right paddle
    if ball.xcor()>380:
        ball.centre()
        l_score.l_point()

#detect the miss at the left paddle
    if ball.xcor()<-380:
        ball.centre()
        r_score.r_point()


screen.exitonclick()