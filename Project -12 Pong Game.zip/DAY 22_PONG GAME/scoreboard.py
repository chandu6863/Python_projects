from turtle import Turtle

class Score(Turtle):
    def __init__(self,a,b):
        super().__init__()
        self.a = a
        self.b = b
        self.color("white")
        self.hideturtle()
        self.penup()
        self.l_score = 0
        self.r_score = 0
        self.goto(self.a,self.b)
        # self.goto(-100,200)
        self.write(self.l_score,align="center",font=("Courier",50,"normal"))

    def l_point(self):
        self.l_score+=1
        self.clear()
        self.write(self.l_score,align="center",font=("Courier",50,"normal"))


    def r_point(self):
        self.r_score+=1
        self.clear()
        self.write(self.r_score,align="center",font=("Courier",50,"normal"))
