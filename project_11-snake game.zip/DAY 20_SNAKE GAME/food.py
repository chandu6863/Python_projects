from turtle import Turtle
from random import randint

SCREEN_SIZE = 280
class Food(Turtle):

    def __init__(self):
        super().__init__()

    # def food(self):
        self.shape("circle")
        self.penup()
        self.shapesize(stretch_len=0.5 , stretch_wid=0.5)
        self.color("orange")
        self.speed("fastest")
        self.random_x = randint(a=-SCREEN_SIZE ,b=SCREEN_SIZE)
        self.random_y = randint(a=-SCREEN_SIZE ,b=SCREEN_SIZE)
        self.goto(self.random_x , self.random_y)
        self.another_food()

    def another_food(self):
        self.random_x = randint(a=-SCREEN_SIZE, b=SCREEN_SIZE)
        self.random_y = randint(a=-SCREEN_SIZE, b=SCREEN_SIZE)
        self.goto(self.random_x, self.random_y)