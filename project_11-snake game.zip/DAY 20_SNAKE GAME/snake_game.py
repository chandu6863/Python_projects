from turtle import Turtle,Screen
import time
from food import Food
from snake import Snake
from score import Score
demo = Turtle()

screen = Screen()
screen.bgcolor("black")
screen.setup(width=600 , height=600)
screen.title("Snake Game")
screen.tracer(0)

snake = Snake()
food = Food()
scoreboard=Score()
screen.listen()
screen.onkey(snake.up , "Up")
screen.onkey(snake.down , "Down")
screen.onkey(snake.left, "Left")
screen.onkey(snake.right , "Right")





is_game_on = True
while is_game_on:
    screen.update()
    time.sleep(0.1)

    snake.move()

    if snake.head_snake.distance(food)<14:
        food.another_food()
        snake.extend()
        scoreboard.score_increase()

    if snake.head_snake.xcor()>290 or snake.head_snake.xcor()<-290 or snake.head_snake.ycor()>290 or snake.head_snake.ycor()<-290:
        is_game_on=False
        scoreboard.game_over()

    for segment in snake.segment:
        if segment == snake.head_snake:
            pass
        elif snake.head_snake.distance(segment) <10:
            is_game_on=False
            scoreboard.game_over()


screen.exitonclick()