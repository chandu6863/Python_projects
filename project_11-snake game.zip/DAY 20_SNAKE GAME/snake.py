from turtle import Turtle
MOVE_DIS = 20
STARTING_POSITION =  [(0,0), (-20,0) ,(-40,0)]
UP = 90
DOWN = 270
LEFT = 180
RIGHT = 0

class Snake:

    def __init__(self):
        self.segment = []
        self.create_snake()
        self.head_snake = self.segment[0]

    def create_snake(self):
        for i in STARTING_POSITION:
            self.add_segment(i)
    def add_segment(self,position):
        snake = Turtle()
        snake.color("white")
        snake.shape("square")
        snake.penup()
        snake.goto(position)
        self.segment.append(snake)

    def extend(self):
        self.add_segment(self.segment[-1].position())

    def move(self):
        for segment1 in range (len(self.segment)-1,0,-1):
            seg_x = self.segment[segment1-1].xcor()
            seg_y = self.segment[segment1-1].ycor()
            self.segment[segment1].goto(seg_x,seg_y)
        self.head_snake.forward(MOVE_DIS)

    def up(self):
        if self.head_snake.heading() != DOWN:
            self.head_snake.setheading(UP)

    def down(self):
        if self.head_snake.heading() != UP:
            self.head_snake.setheading(DOWN)

    def left(self):
        if self.head_snake.heading() != RIGHT:
            self.head_snake.setheading(LEFT)

    def right(self):
        if self.head_snake.heading() != LEFT:
            self.head_snake.setheading(RIGHT)

