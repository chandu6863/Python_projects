from turtle import Turtle
LEVEL_POS = (-80 , 250)
FONT = ("Courier", 24, "normal")


class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.current_lvl = 1
        self.hideturtle()
        self.penup()
        self.color("white")

    def scorecard(self):
        self.goto(LEVEL_POS)
        self.write(f"level:{self.current_lvl}",align="left",font=FONT)

    def lvl_increament(self):
        self.current_lvl+=1

