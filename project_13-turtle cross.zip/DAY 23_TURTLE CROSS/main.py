import time
from turtle import Screen
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard

player = Player()
car = CarManager()
score = Scoreboard()

screen = Screen()
screen.title("Turtle Cross")
screen.setup(width=600, height=600)
screen.bgcolor("black")
screen.tracer(0)
screen.listen()
screen.onkey(player.move,"Up")

game_is_on = True
while game_is_on:
    time.sleep(0.1)
    screen.update()
    score.scorecard()
    car.create_cars()
    car.move_cars()

#     Detecting the collision of the turtle car
    for car_temp in car.all_cars:
        if car_temp.distance(player)<15:
            game_is_on = False
            player.lost()

# detecting the weather turtle reach the other side of the screen to win the game
    if player.reach():
        player.go_to_start()
        car.movement_increase()
        score.clear()
        score.lvl_increament()

screen.exitonclick()