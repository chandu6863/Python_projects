import turtle
import random

turtle.colormode(255)
tur = turtle.Turtle()
colour_list=[(237, 237, 236), (161, 52, 80), (243, 237, 239), (236, 242, 238), (240, 131, 112), (13, 131, 183), (225, 121, 171), (237, 239, 243), (250, 196, 57), (134, 189, 35)]
for i in range(50):
    tur.dot(20,random.choice(colour_list))
    tur.penup()
    tur.forward(50)
    if i==6:
        tur.right(90)


screen=turtle.Screen()
screen.exitonclick()