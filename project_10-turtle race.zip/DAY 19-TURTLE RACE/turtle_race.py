from random import randint
from turtle import Turtle,Screen



is_game_on=False
screen = Screen()
screen.setup(width=500,height=400)
win=screen.textinput("Make a Bet.","which colour turtle will win: ")
colours = ["red","orange","yellow","brown","black","violet"]
list1=[-70,-40,-10,20,50,80]
all_turtles=[]

for i in range(0,6):
    janu = Turtle()
    janu.shape("turtle")
    janu.color(colours[i])
    janu.penup()
    janu.goto(x=-240  , y=list1[i])
    all_turtles.append(janu)

if win:
    is_game_on=True

while is_game_on:

    for turtle in all_turtles:
        if turtle.xcor()>230:
            is_game_on=False
            winning_colour = turtle.pencolor()
            if winning_colour==win:
                print(f"You've won .The {winning_colour} turtle won the race!!")
            else:
                print(f"You've lost .The {winning_colour} turtle won the race!!")
            break
        move = randint(0,10)
        turtle.forward(move)



screen.exitonclick()